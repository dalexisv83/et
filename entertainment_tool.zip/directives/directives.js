(function(angular) {
    'use strict';
    angular.module('entertainment.directives', [
        'directives.dropCheck',
        'directives.cycleSlideshow',
        'directives.datepicker'
    ]);
}(window.angular));
