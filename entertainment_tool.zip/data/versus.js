var versus = [{
    "service": "DIRECTV",
    "price": "Included with Pay TV subscription",
    "simDevices": 5,
    "live": true,
    "sports": true,
    "connection": false
}, {
    "service": "Sling TV",
    "price": "$20/month  Base package + Add-on $5/month",
    "simDevices": 1,
    "live": true,
    "sports": true,
    "connection": true
}, {
    "service": "Amazon Prime Video",
    "price": "$99/year",
    "simDevices": 2,
    "live": true,
    "sports": false,
    "connection": false
}, {
    "service": "Hulu",
    "price": "$7.99/month",
    "simDevices": 1,
    "live": true,
    "sports": false,
    "connection": true
}, {
    "service": "Netflix",
    "price": "$7.99-$11.99/month",
    "simDevices": 4,
    "live": false,
    "sports": false,
    "connection": true
}];